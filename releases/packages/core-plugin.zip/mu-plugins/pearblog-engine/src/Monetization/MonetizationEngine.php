<?php
/**
 * Monetisation engine – injects monetisation markup into generated content.
 *
 * v1: Google AdSense ad units
 * v2: Affiliate links (Booking.com deep-link boxes)
 * v3: SaaS CTA (keyword-matched product recommendations)
 *
 * @package PearBlogEngine\Monetization
 */

declare(strict_types=1);

namespace PearBlogEngine\Monetization;

use PearBlogEngine\Tenant\SiteProfile;

/**
 * Selects and applies the correct monetisation strategy for a site profile.
 */
class MonetizationEngine {

	/** Relative position (0–1) at which the second box is inserted. */
	private const BOX_POSITION_RATIO = 0.66;

	/** @var SiteProfile */
	private SiteProfile $profile;

	public function __construct( SiteProfile $profile ) {
		$this->profile = $profile;
	}

	/**
	 * Inject monetisation elements into the article content.
	 *
	 * @param int    $post_id   WordPress post ID (used to retrieve site options).
	 * @param string $content   Article content (HTML or Markdown).
	 * @return string           Content with monetisation markup inserted.
	 */
	public function apply( int $post_id, string $content ): string {
		// Detect funnel stage for intelligent AdSense placement.
		$post = get_post( $post_id );
		if ( $post instanceof \WP_Post ) {
			$detector     = new FunnelStageDetector();
			$funnel_stage = $detector->detect( $post->post_title, $content );

			// Store funnel stage as post meta for analytics/reporting.
			update_post_meta( $post_id, 'pearblog_funnel_stage', $funnel_stage );

			/**
			 * Action: pearblog_funnel_stage_detected
			 *
			 * @param int    $post_id      Post ID.
			 * @param string $funnel_stage Detected stage (tofu/mofu/bofu).
			 */
			do_action( 'pearblog_funnel_stage_detected', $post_id, $funnel_stage );
		}

		$monetized = match ( $this->profile->monetization ) {
			'affiliate' => $this->apply_affiliate( $post_id, $content ),
			'saas'      => $this->apply_saas_cta( $content ),
			default     => $this->apply_adsense( $post_id, $content ),
		};

		/**
		 * Filter: pearblog_monetized_content
		 *
		 * Allows external code to post-process the monetised content.
		 *
		 * @param string      $monetized Content with monetisation injected.
		 * @param int         $post_id   Post ID.
		 * @param SiteProfile $profile   Active site profile.
		 */
		return (string) apply_filters( 'pearblog_monetized_content', $monetized, $post_id, $this->profile );
	}

	// -----------------------------------------------------------------------
	// v1 – AdSense
	// -----------------------------------------------------------------------

	/**
	 * Apply funnel-aware AdSense placement strategy.
	 *
	 * TOFU (informational): Full AdSense enabled.
	 * MOFU (consideration): Limited AdSense (single placement only).
	 * BOFU (decision):      AdSense disabled (focus on conversions).
	 *
	 * @param int    $post_id WordPress post ID.
	 * @param string $content Article content.
	 * @return string Content with AdSense units injected (or unchanged).
	 */
	private function apply_adsense( int $post_id, string $content ): string {
		$publisher_id = (string) get_option( 'pearblog_adsense_publisher_id', '' );

		if ( '' === $publisher_id ) {
			return $content;
		}

		// Check funnel stage to determine AdSense strategy.
		$funnel_stage = (string) get_post_meta( $post_id, 'pearblog_funnel_stage', true );
		$detector     = new FunnelStageDetector();

		// Skip AdSense entirely for BOFU content (or if strategy says no).
		if ( ! $detector->should_enable_adsense( $funnel_stage ) ) {
			return $content;
		}

		$ad_unit = $this->build_adsense_unit( $publisher_id );

		// MOFU: Limited placement (single ad after first paragraph only).
		if ( $detector->should_limit_placement( $funnel_stage ) ) {
			return $this->inject_single_ad( $content, $ad_unit );
		}

		// TOFU: Full placement (after first paragraph + at 66% mark).
		return $this->inject_box( $content, $ad_unit );
	}

	/**
	 * Build an AdSense ad unit HTML block.
	 *
	 * @param string $publisher_id AdSense publisher ID (ca-pub-...).
	 * @return string HTML for the ad unit.
	 */
	private function build_adsense_unit( string $publisher_id ): string {
		return sprintf(
			'<div class="pearblog-ad pearblog-ad--adsense">' .
			'<ins class="adsbygoogle" style="display:block" ' .
			'data-ad-client="%s" data-ad-slot="auto" data-ad-format="auto" ' .
			'data-full-width-responsive="true"></ins>' .
			'<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>' .
			'</div>',
			esc_attr( $publisher_id )
		);
	}

	/**
	 * Inject a single ad unit after the first paragraph (limited placement).
	 *
	 * @param string $content Article HTML.
	 * @param string $ad_unit Ad unit HTML.
	 * @return string Modified content.
	 */
	private function inject_single_ad( string $content, string $ad_unit ): string {
		// Insert the ad unit after the first paragraph.
		$first_para = strpos( $content, '</p>' );
		if ( false !== $first_para ) {
			return substr_replace( $content, "\n\n" . $ad_unit . "\n\n", $first_para + 4, 0 );
		}

		return $content . "\n\n" . $ad_unit;
	}

	// -----------------------------------------------------------------------
	// v2 – Affiliate (Booking.com deep-link boxes)
	// -----------------------------------------------------------------------

	/**
	 * Inject Booking.com affiliate boxes into content at strategic positions.
	 *
	 * Boxes are inserted after the first paragraph and at the 66 % mark.
	 * When no affiliate ID is configured the content is returned unchanged,
	 * but the pearblog_affiliate_content filter still fires so external
	 * plugins can add their own injection.
	 *
	 * @param int    $post_id WordPress post ID.
	 * @param string $content Article content (HTML).
	 * @return string Content with affiliate boxes injected.
	 */
	private function apply_affiliate( int $post_id, string $content ): string {
		$affiliate_id = (string) get_option( 'pearblog_booking_affiliate_id', '' );

		// Detect location: post meta first, then keyword scan of title + body.
		$location = (string) get_post_meta( $post_id, 'pearblog_location', true );
		if ( '' === $location ) {
			$post = get_post( $post_id );
			if ( $post instanceof \WP_Post ) {
				$location = $this->extract_location(
					$post->post_title . ' ' . wp_strip_all_tags( $post->post_content )
				);
			}
		}

		$box              = $this->build_affiliate_box( $affiliate_id, $location );
		$content_with_box = '' !== $box ? $this->inject_box( $content, $box ) : $content;

		/**
		 * Filter: pearblog_affiliate_content
		 *
		 * Allows external plugins to post-process or replace affiliate injection.
		 *
		 * @param string $content_with_box Content with affiliate box(es) injected.
		 * @param int    $post_id          Post ID.
		 * @param string $location         Auto-detected location string (may be empty).
		 * @param string $affiliate_id     Booking.com affiliate / partner ID.
		 */
		return (string) apply_filters( 'pearblog_affiliate_content', $content_with_box, $post_id, $location, $affiliate_id );
	}

	/**
	 * Scan text for known location keywords and return the first match.
	 *
	 * The keyword list can be extended via the pearblog_location_keywords filter.
	 *
	 * @param string $text Plain text to search.
	 * @return string Matched location or empty string.
	 */
	private function extract_location( string $text ): string {
		/** @var string[] $keywords */
		$keywords = (array) apply_filters( 'pearblog_location_keywords', [
			'Babia Góra', 'Zakopane', 'Kraków', 'Warszawa', 'Gdańsk',
			'Tatry', 'Karkonosze', 'Bieszczady', 'Mazury', 'Karpacz',
			'Wrocław', 'Poznań', 'Łódź', 'Szczecin', 'Lublin',
			'Białystok', 'Katowice', 'Rzeszów', 'Toruń', 'Bydgoszcz',
		] );

		foreach ( $keywords as $keyword ) {
			if ( false !== stripos( $text, $keyword ) ) {
				return $keyword;
			}
		}

		return '';
	}

	/**
	 * Build a Booking.com deep-link affiliate box.
	 *
	 * Returns an empty string when neither an affiliate ID nor a location is
	 * available, so callers can skip injection gracefully.
	 *
	 * @param string $affiliate_id Booking.com partner/affiliate ID.
	 * @param string $location     Destination location name.
	 * @return string HTML for the affiliate box, or empty string.
	 */
	private function build_affiliate_box( string $affiliate_id, string $location ): string {
		if ( '' === $affiliate_id ) {
			return '';
		}

		$query_args = [ 'aid' => rawurlencode( $affiliate_id ), 'lang' => 'pl' ];
		if ( '' !== $location ) {
			$query_args['ss'] = rawurlencode( $location );
		}
		$search_url = add_query_arg( $query_args, 'https://www.booking.com/searchresults.html' );

		$title = '' !== $location
			/* translators: %s: destination name */
			? sprintf( __( 'Szukasz noclegów w %s?', 'pearblog-engine' ), $location )
			: __( 'Znajdź noclegi w dobrej cenie', 'pearblog-engine' );

		return sprintf(
			'<div class="pearblog-affiliate pearblog-affiliate--booking">' .
			'<p class="pearblog-affiliate__title">%s</p>' .
			'<a class="pearblog-affiliate__cta" href="%s" target="_blank" rel="noopener sponsored">%s</a>' .
			'</div>',
			esc_html( $title ),
			esc_url( $search_url ),
			esc_html__( 'Sprawdź oferty na Booking.com →', 'pearblog-engine' )
		);
	}

	/**
	 * Inject a box after the first paragraph and at the ~66 % mark.
	 *
	 * Shared by both affiliate and SaaS CTA strategies.
	 *
	 * @param string $content Full article HTML.
	 * @param string $box     Box HTML to inject.
	 * @return string Modified content.
	 */
	private function inject_box( string $content, string $box ): string {
		// Split on </p> boundaries to work paragraph by paragraph.
		$paragraphs = preg_split( '/(?<=<\/p>)/u', $content, -1, PREG_SPLIT_NO_EMPTY );
		if ( false === $paragraphs ) {
			return $content . "\n\n" . $box;
		}

		$count = count( $paragraphs );
		if ( $count <= 1 ) {
			return $content . "\n\n" . $box;
		}

		$mid_point = (int) round( $count * self::BOX_POSITION_RATIO );
		$result    = '';

		foreach ( $paragraphs as $index => $paragraph ) {
			$result .= $paragraph;

			if ( 0 === $index ) {
				$result .= "\n\n" . $box . "\n\n";
			} elseif ( $mid_point > 1 && $index === $mid_point - 1 ) {
				$result .= "\n\n" . $box . "\n\n";
			}
		}

		return $result;
	}

	// -----------------------------------------------------------------------
	// v3 – SaaS CTA
	// -----------------------------------------------------------------------

	/**
	 * Inject SaaS product CTA boxes into content.
	 *
	 * Reads configured SaaS products from the `pearblog_saas_products` option,
	 * matches product keywords against article content, and injects up to one
	 * CTA box after the first paragraph and at the 66 % mark.
	 *
	 * When no products match (or none are configured), the filter
	 * `pearblog_saas_cta_content` still fires so external plugins can add
	 * their own injection.
	 *
	 * @param string $content Article content (HTML).
	 * @return string Content with SaaS CTA boxes injected.
	 */
	private function apply_saas_cta( string $content ): string {
		$products = $this->get_saas_products();
		$matched  = $this->match_saas_products( $content, $products );

		if ( ! empty( $matched ) ) {
			$box     = $this->build_saas_cta_box( $matched[0] );
			$content = $this->inject_box( $content, $box );
		}

		/**
		 * Filter: pearblog_saas_cta_content
		 * Allows SaaS CTA injection by a dedicated integration plugin.
		 *
		 * @param string $content  Content (possibly with CTA injected).
		 * @param array  $matched  Matched product definitions.
		 */
		return (string) apply_filters( 'pearblog_saas_cta_content', $content, $matched );
	}

	/**
	 * Retrieve configured SaaS products.
	 *
	 * Each product is an associative array:
	 *   - name        (string) Product display name.
	 *   - url         (string) Affiliate/referral URL.
	 *   - keywords    (string[]) Keywords that trigger this product's CTA.
	 *   - description (string) Short value-proposition shown in the CTA box.
	 *   - cta_text    (string) Button label (defaults to "Try {name} →").
	 *
	 * Products can be extended via the `pearblog_saas_products` filter.
	 *
	 * @return array<int, array{name: string, url: string, keywords: string[], description: string, cta_text: string}>
	 */
	private function get_saas_products(): array {
		$raw = get_option( 'pearblog_saas_products', '[]' );

		if ( is_string( $raw ) ) {
			$products = json_decode( $raw, true );
			if ( ! is_array( $products ) ) {
				$products = [];
			}
		} else {
			$products = is_array( $raw ) ? $raw : [];
		}

		/** @var array $products */
		return (array) apply_filters( 'pearblog_saas_products', $products );
	}

	/**
	 * Match SaaS products against article content using keyword scanning.
	 *
	 * Returns all matched products sorted by relevance (number of keyword hits
	 * descending).
	 *
	 * @param string $content  Article HTML.
	 * @param array  $products Products array from {@see get_saas_products()}.
	 * @return array Matched products.
	 */
	private function match_saas_products( string $content, array $products ): array {
		if ( empty( $products ) ) {
			return [];
		}

		$text    = mb_strtolower( wp_strip_all_tags( $content ) );
		$matches = [];

		foreach ( $products as $product ) {
			if ( empty( $product['keywords'] ) || empty( $product['name'] ) || empty( $product['url'] ) ) {
				continue;
			}

			$keywords = is_array( $product['keywords'] ) ? $product['keywords'] : explode( ',', (string) $product['keywords'] );
			$hits     = 0;

			foreach ( $keywords as $kw ) {
				$kw = trim( $kw );
				if ( '' !== $kw && false !== mb_strpos( $text, mb_strtolower( $kw ) ) ) {
					++$hits;
				}
			}

			if ( $hits > 0 ) {
				$product['_hits'] = $hits;
				$matches[]        = $product;
			}
		}

		// Sort by number of keyword hits (highest first).
		usort( $matches, static fn( array $a, array $b ): int => $b['_hits'] <=> $a['_hits'] );

		return $matches;
	}

	/**
	 * Build a SaaS product CTA box.
	 *
	 * @param array $product Product definition.
	 * @return string HTML for the CTA box.
	 */
	private function build_saas_cta_box( array $product ): string {
		$name        = $product['name'] ?? '';
		$url         = $product['url'] ?? '';
		$description = $product['description'] ?? '';
		$cta_text    = $product['cta_text'] ?? '';

		if ( '' === $name || '' === $url ) {
			return '';
		}

		if ( '' === $cta_text ) {
			/* translators: %s: SaaS product name */
			$cta_text = sprintf( __( 'Try %s →', 'pearblog-engine' ), $name );
		}

		$title = '' !== $description
			? esc_html( $description )
			/* translators: %s: SaaS product name */
			: esc_html( sprintf( __( 'Recommended tool: %s', 'pearblog-engine' ), $name ) );

		return sprintf(
			'<div class="pearblog-saas-cta">' .
			'<p class="pearblog-saas-cta__title">%s</p>' .
			'<a class="pearblog-saas-cta__button" href="%s" target="_blank" rel="noopener sponsored" data-saas-product="%s">%s</a>' .
			'</div>',
			$title,
			esc_url( $url ),
			esc_attr( $name ),
			esc_html( $cta_text )
		);
	}
}
